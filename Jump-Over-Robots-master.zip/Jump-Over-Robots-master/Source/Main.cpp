#include "Main.h"
#include "Collectible.cpp"
#include "LevelLayout.cpp"
#include "Enemy.cpp"
#include "Player.cpp"
using namespace std;

int main()
{
	return 0;
}